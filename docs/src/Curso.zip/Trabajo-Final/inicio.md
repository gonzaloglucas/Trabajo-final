# ¡Bienvenido/a!
![metalocus_biblioteca-getafe_14_1080_0](https://user-images.githubusercontent.com/90325917/145478452-18c70087-689c-404e-be66-72bac2922728.jpg)

### Soy Gonzalo Giménez y este es mi proytecto final para la asignatura de Periodismo de Datos.

- Este es el menú de Inicio, desde donde podrás entrar en los distintos contenidos de la página web. Estás dentro de una compilación de mis trabajos a lo largo del curso. Por lo tanto este proyecto es la última de todas las prácticas y mi trabajo final.

  - En la primera pestaña llamada **Práctica 1** encontrarás una breve observación sobre la subida de la luz.
  - En la segunda pestaña llamada **Práctica 2** figuta un comentario sobre un estudio demográfico del acceso a internet.
  - En la tercera pestaña llamada **Práctica 3** hay disponible un análisis sobre la evolución de un tweet en el tiempo.
  - En la cuarta pestaña llamada **Práctica 4** tendremos un extenso comentario sobre la inversión en I+D por autonomías.
  - Por último, en la pestaña de **Metodología** explico de forma más pausada el prodecimiento de creación del proyecto.
