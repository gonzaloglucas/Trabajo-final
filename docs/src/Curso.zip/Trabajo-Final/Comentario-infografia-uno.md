# **PRIMER COMENTARIO INFOGRAFÍA**

## Infografía: "Precio de la luz en abril"
### Duente: Nedgia

![Precios_luz_abril_2](https://user-images.githubusercontent.com/90325917/133136219-ee4e090e-ca4f-4468-9694-1bf1c9dafc0c.jpg)

- Se muestran dos colores diferenciados, uno para la factura mensual y otro para el precio mayorista
- Su evolución se muestra en una línea del tiempo en los meses de abril de los últimos años. Aunque suelan ir parejos, este último mes de abril de 2021 han alcanzado un máximo histórico.
- Podemos ver la factura mensual por debajo del índice del precio mayorista de la OMIE.
- Aunque presenten esta diferencia, en su evolución en el tiempo mantienen un contínuo de subidas y bajadas parejas.
- Se ha elegido visualizar los datos en el punto coincidente de cada mes de abril de cada año con su precio en euros (€).
